"""Unit tests for the math core.  Run from the project folder:  python -m pytest -q"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import phantoms  # noqa: E402
import radon  # noqa: E402
import recon  # noqa: E402


def test_matrix_is_sparse_and_shaped():
    n, k = 16, 10
    nd = radon.default_n_detectors(n)
    A = radon.build_matrix(n, radon.make_angles(k), nd)
    assert A.shape == (k * nd, n * n)
    assert A.nnz < 0.15 * A.shape[0] * A.shape[1]
    assert A.data.min() > 0


def test_horizontal_ray_crosses_whole_image():
    # theta = 0: rays travel along +x, so a ray inside the image has length exactly n
    n = 16
    A = radon.build_matrix(n, [0.0], 24)
    sums = np.asarray(A.sum(axis=1)).ravel()
    offsets = radon.detector_positions(n, 24)
    inside = np.abs(offsets) < n / 2 - 1e-9
    assert np.allclose(sums[inside], n)
    assert np.allclose(sums[~inside], 0)


def test_no_entry_exceeds_pixel_diagonal():
    A = radon.build_matrix(16, radon.make_angles(30), 24)
    assert A.data.max() <= np.sqrt(2) + 1e-9


def test_uniform_image_conserves_area():
    # integrating the chord length over the detector offsets must give the image area n^2
    n, k = 32, 12
    nd = radon.default_n_detectors(n)
    A = radon.build_matrix(n, radon.make_angles(k), nd)
    b = radon.forward(A, np.ones((n, n)), k)
    ds = 2 * (n * np.sqrt(2) / 2) / nd
    assert np.allclose(b.sum(axis=1) * ds, n * n, rtol=0.01)


def test_phantoms_in_unit_range():
    for name in phantoms.PHANTOMS:
        img = phantoms.get_phantom(name, 32)
        assert img.shape == (32, 32)
        assert img.min() >= 0 and abs(img.max() - 1.0) < 1e-12


def test_noise_free_recovery_with_many_angles():
    n = 16
    A = radon.build_matrix(n, radon.make_angles(60), radon.default_n_detectors(n))
    U, s, Vt = recon.svd_decompose(A)
    assert recon.numerical_rank(s, A.shape) == n * n
    x = phantoms.shepp_logan(n)
    rec = recon.pinv_recon(U, s, Vt, A @ x.ravel(), n, A.shape)
    assert recon.rmse(x, rec) < 1e-8


def test_few_angles_give_null_space_ghost():
    n = 16
    A = radon.build_matrix(n, radon.make_angles(3), radon.default_n_detectors(n))
    U, s, Vt = recon.svd_decompose(A)
    rank = recon.numerical_rank(s, A.shape)
    assert rank < n * n
    x = phantoms.shepp_logan(n)
    g = recon.null_space_component(Vt, s, x, A.shape)
    assert np.abs(g).max() > 1e-3  # a genuine invisible component
    assert np.abs(A @ g.ravel()).max() < 1e-9  # ... which the scanner cannot see
    assert np.allclose(A @ (x + 2.5 * g).ravel(), A @ x.ravel(), atol=1e-9)


def test_tsvd_with_all_components_equals_pinv():
    n = 16
    A = radon.build_matrix(n, radon.make_angles(40), radon.default_n_detectors(n))
    U, s, Vt = recon.svd_decompose(A)
    b = A @ phantoms.blocks(n).ravel()
    r = recon.numerical_rank(s, A.shape)
    assert np.allclose(recon.tsvd_recon(U, s, Vt, b, r, n), recon.pinv_recon(U, s, Vt, b, n, A.shape))


def test_ridge_with_tiny_lambda_equals_pinv():
    n = 16
    A = radon.build_matrix(n, radon.make_angles(40), radon.default_n_detectors(n))
    U, s, Vt = recon.svd_decompose(A)
    b = A @ phantoms.blocks(n).ravel()
    assert np.allclose(recon.ridge_recon(U, s, Vt, b, 1e-14, n), recon.pinv_recon(U, s, Vt, b, n, A.shape), atol=1e-6)


def test_regularisation_beats_plain_least_squares_on_noisy_data():
    n = 24
    A = radon.build_matrix(n, radon.make_angles(40), radon.default_n_detectors(n))
    U, s, Vt = recon.svd_decompose(A)
    x = phantoms.shepp_logan(n)
    b = recon.add_noise(A @ x.ravel(), 5.0, seed=1)
    plain = recon.rmse(x, recon.pinv_recon(U, s, Vt, b, n, A.shape))
    assert recon.tsvd_sweep(U, s, Vt, b, x, A.shape)[1].min() < 0.9 * plain
    assert recon.ridge_sweep(U, s, Vt, b, x, A.shape)[1].min() < 0.9 * plain


def test_sweep_matches_direct_reconstruction():
    n = 16
    A = radon.build_matrix(n, radon.make_angles(30), radon.default_n_detectors(n))
    U, s, Vt = recon.svd_decompose(A)
    x = phantoms.shepp_logan(n)
    b = recon.add_noise(A @ x.ravel(), 2.0, seed=3)
    ks, errs = recon.tsvd_sweep(U, s, Vt, b, x, A.shape, ks=[5, 50, 120])
    for k, e in zip(ks, errs):
        assert abs(e - recon.rmse(x, recon.tsvd_recon(U, s, Vt, b, k, n))) < 1e-10
    rels, errs = recon.ridge_sweep(U, s, Vt, b, x, A.shape, rels=[1e-6, 1e-3])
    for r, e in zip(rels, errs):
        assert abs(e - recon.rmse(x, recon.ridge_recon(U, s, Vt, b, r * s[0] ** 2, n))) < 1e-10


def test_lsqr_matches_pinv_noise_free():
    n = 16
    A = radon.build_matrix(n, radon.make_angles(60), radon.default_n_detectors(n))
    x = phantoms.shepp_logan(n)
    rec = recon.lsqr_recon(A, A @ x.ravel(), n, iters=2000)
    assert recon.rmse(x, rec) < 1e-4
